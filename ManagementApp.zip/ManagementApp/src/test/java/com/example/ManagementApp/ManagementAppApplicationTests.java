package com.example.ManagementApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
