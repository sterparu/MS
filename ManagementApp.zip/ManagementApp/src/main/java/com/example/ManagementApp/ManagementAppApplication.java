package com.example.ManagementApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagementAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagementAppApplication.class, args);
	}

}
